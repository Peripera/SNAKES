#include "../include/input.h"

#include <iostream>

using namespace std;

Input::Input(int maxTurns, int num_players,int maxTiles, int snakes,int ladders, int num_penalties,int num_rewards): MyGame(maxTurns, num_players,maxTiles, snakes,ladders, num_penalties,num_rewards){}

void Input::start(){
  board.print_board();
  printInstructions();
  MyGame::initializePositions();
  bool end=false;
  char command;
  while (end==false) {
    std::cin >> command;
    if (command == 'E' || command == 'e') {
      printThanksForPlaying();
      printGameOver();
      break;
    } else if (command == 'C' || command == 'c') {
      MyGame::executeTurn();
      MyGame::endGame();
    } else {
      printInvalidOption();
    }
  }
}

