#include "../include/board.h"
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <vector>

Board::Board(int maxTiles, int snakes, int ladders)
    : board_size(maxTiles), snakes(snakes), ladders(ladders) {

  getRandomSpecial();
  
}

void Board::getRandomSpecial(){
  std::srand(static_cast<unsigned int>(std::time(nullptr))); // seed for random
  board = std::vector<char>(board_size, 'N'); // initialize board with 'N'
  int i = -1;
  int amountSpecial= snakes+ladders;
  
  while (special_boxes.size() < amountSpecial) {
    int random_number = std::rand() % board_size; // random number between 0 and 29
    bool repeated = false;
    if (i == -1) {
      special_boxes.push_back(random_number);
      i += 1;
    } else {
      for (int each_num : special_boxes) {
        if (random_number == each_num) {
          repeated = true;
          break;
        }
      }

      if (repeated == false) {
        special_boxes.push_back(random_number);
        i += 1;
      }
    }

    if (i < snakes) {
      board[special_boxes[i]] = 'S';
    } else {
      board[special_boxes[i]] = 'L';
    }
  }
}

void Board::print_board() {
  std::cout << "This is the board" << std::endl;
  for (char each_num : board) {
    std::cout << "[" << each_num << "]";
  }
  std::cout << std::endl;
}

std::vector<char> Board::get_board() { return board; }