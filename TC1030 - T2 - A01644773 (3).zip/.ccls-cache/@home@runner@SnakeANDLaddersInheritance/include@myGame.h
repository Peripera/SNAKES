#ifndef MYGAME_H
#define MYGAME_H

#include "Dice.h"
#include "board.h"
#include <vector>

using namespace std;

class MyGame {
protected:
  Board board;
  Dice dice;
  int turnCount;
  int currentPlayer;
   
  vector<int> playerPositions;// Position of player 1 is stored in index 0 and player 2 in index 1
  int maxTurns; // parameter for the max number of turns that the player will
                // give
  int num_players;
  int maxTiles;
  int snakes;
  int ladders;
  int num_penalties;
  int num_rewards;
  bool end=false;

  // Print instructions
  void printInstructions();
  void printInvalidOption();
  void printGameOver();
  void printMaxTurnsReached();
  void printWinner(int player);
  void printThanksForPlaying();

  void initializePositions();
  void endGame();

public:
  MyGame(int maxTurns, int num_players, int maxTiles, int snakes, int ladders,
         int num_penalties, int num_rewards);
  // Functions to override
  void executeTurn();

  // Execute the game
  virtual void start();
};

#endif
