#ifndef DICE_H
#define DICE_H

#include <cstdlib>
#include <ctime>

using namespace std;

class Dice{
private:
   int sides;
public:
   int result;

   Dice(void){
     result = 0;
     sides = 12;
     srand((unsigned int) time(NULL));  // Seed the random number generator once
   }

   int roll(){
    return (rand() % sides) + 1;
   }
};

#endif 

