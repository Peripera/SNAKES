#ifndef INPUT_H
#define INPUT_H
#include "myGame.h"

class Input : public MyGame {
public:
  Input(int maxTurns, int num_players, int maxTiles, int snakes, int ladders,
        int num_penalties, int num_rewards);
  void executeTurn();
  void start() override;
};

#endif
