/*
#include "../include/noInput.h"

#include <iostream>

using namespace std;
NoInput::NoInput(int maxTurns, int num_players,int maxTiles, int snakes,int ladders, int num_penalties,int num_rewards):Input(int maxTurns, int num_players,int maxTiles, int snakes,int ladders, int num_penalties,int num_rewards){

}
void NoInput::executeTurn(){
  cout<<"ENTREEE NO INPUT" <<endl;
 
}
*/
