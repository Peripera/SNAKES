#ifndef BOARD_H
#define BOARD_H

#include <vector>

class Board {
private:
  int board_size;
  int snakes;
  int ladders;
  int num_penalties;
  int num_rewards;
  std::vector<char> board;
  std::vector<int> special_boxes;

public:
  Board(int maxTiles, int snakes, int ladders);
  void print_board();
  void getRandomSpecial();

  std::vector<char> get_board();
};

#endif
