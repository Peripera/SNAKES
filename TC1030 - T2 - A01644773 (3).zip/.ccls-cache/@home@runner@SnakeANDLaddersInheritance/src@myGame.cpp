#include "../include/myGame.h"
#include "../include/board.h"
#include "../include/input.h"
#include <iostream>

MyGame::MyGame(int maxTurns, int num_players, int maxTiles, int snakes,
               int ladders, int num_penalties, int num_rewards)
    : turnCount(0), currentPlayer(0), maxTurns(maxTurns),
      num_players(num_players), maxTiles(maxTiles), snakes(snakes),
      ladders(ladders), num_penalties(num_penalties), num_rewards(num_rewards),
      board(maxTiles, snakes, ladders) {}
void MyGame::printInstructions() {
  std::cout << "Press C to continue next turn, or E to end the game:"
            << std::endl;
}

void MyGame::printInvalidOption() {
  std::cout << "Invalid option, please press C to continue next turn or E to "
               "end the game"
            << std::endl;
}

void MyGame::printGameOver() { std::cout << "-- GAME OVER --" << std::endl; }

void MyGame::printMaxTurnsReached() {
  std::cout << "The maximum number of turns has been reached..." << std::endl;
}

void MyGame::printWinner(int player) {
  std::cout << "Player " << player << " is the winner!!!" << std::endl;
}

void MyGame::printThanksForPlaying() {
  std::cout << "Thanks for playing!!!" << std::endl;
}

void MyGame::initializePositions() {
  for (int i = 0; i < num_players; i++) {
    playerPositions.push_back(1);
  }
}
void MyGame::endGame(){
  end=false;
  if (playerPositions[currentPlayer] >= maxTiles) {
    printWinner(currentPlayer + 1);
    printGameOver();
    end = true;

  } else if (turnCount >= maxTurns) {
    printMaxTurnsReached();
    printGameOver();
    end = true;
  }
  currentPlayer = (currentPlayer + 1) % num_players;
}
void MyGame::start() { // runs automaticaally, "a"
  board.print_board();
  printInstructions();
  initializePositions();
  // Input prueba(maxTurns, num_players,maxTiles, snakes,ladders,
  // num_penalties,num_rewards); prueba.executeTurn();
  char command;
  while (end == false) {
    executeTurn();
    endGame();
  }
}

void MyGame::executeTurn() {
  turnCount++;
  int currentPosition = playerPositions[currentPlayer]; // currentPlayer values
  int diceRoll = dice.roll();
  int newPosition = currentPosition + diceRoll;

  if (newPosition > maxTiles) {
    newPosition = maxTiles; // Ensure player does not go beyond last box
  }
  std::vector<char> gameBoard = board.get_board();
  char boxType = gameBoard[newPosition - 1];

  if (boxType == 'S') {
    newPosition -= num_penalties;
    if (newPosition < 1) {
      newPosition = 1;
    }
  } else if (boxType == 'L') {
    newPosition += num_rewards;
    if (newPosition > maxTiles) {
      newPosition = maxTiles;
    }
  }

  playerPositions[currentPlayer] = newPosition;

  std::cout << turnCount << " " << (currentPlayer + 1) << " " << currentPosition
            << " " << diceRoll << " " << boxType << " " << newPosition << "\n";
}