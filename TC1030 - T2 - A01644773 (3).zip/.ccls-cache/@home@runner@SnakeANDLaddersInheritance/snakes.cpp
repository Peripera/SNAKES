#include "include/Dice.h"
#include "include/board.h"
#include "include/myGame.h"
#include "include/input.h"
#include <iostream>

int main() {
  // declaring variables
  int maxTurns, maxTiles, snakes, ladders, num_penalties, num_rewards,
      num_players;
  char gameMode;

  std::cout << "Welcome to the game Snakes & Ladders" << std::endl;

  // set the parameters for the rest of the game
  std::cout << "What will be the maximum number of tiles for the board?: ";
  std::cin >> maxTiles;
  while (maxTiles <= 0) {
    cout << "Size board must be greater than 0" << endl;
    cin >> maxTiles;
  }
  std::cout << "What will be the maximum number of snakes for the game?: ";
  std::cin >> snakes;
  while (snakes >= maxTiles) {
    cout << "The number of snakes must be less than the number of tiles"
         << endl;
    cin >> snakes;
  }

  std::cout << "What will be the maximum number of ladders for the game?: ";
  std::cin >> ladders;
  while (ladders >= maxTiles) {
    cout << "The number of ladders must be less than the number of tiles"
         << endl;
    cin >> ladders;
  }

  std::cout << "What will be the maximum number of penalties for the game?: ";
  std::cin >> num_penalties;
  while (num_penalties <= 0) {
    cout << "The number of penalties must be greater than 0" << endl;
    cin >> num_penalties;
  }

  std::cout << "What will be the maximum number of rewards for the game?: ";
  std::cin >> num_rewards;
  while (num_rewards <= 0) {
    cout << "The number of rewards must be greater than 0" << endl;
    cin >> num_rewards;
  }

  std::cout << "How many players will be playing the game?: ";
  std::cin >> num_players;
  while (num_players <= 0) {
    cout << "The number of players must be greater than 0" << endl;
    cin >> num_players;
  }

  std::cout << "What will be the maximum number of turns for the game?: ";
  std::cin >> maxTurns;
  while (maxTurns <= 0) {
    cout << "The number of turns must be greater than 0" << endl;
    cin >> maxTurns;
  }

  // lets the user select game type 
  std::cout<<"Choose play style (A or M): "<<endl;
  cin >> gameMode;
  while (true){
    if (gameMode == 'A' || gameMode == 'a'){
      MyGame gameParent(maxTurns, num_players, maxTiles, snakes, ladders, num_penalties,
      num_rewards);
      gameParent.start();
      break;
    }
    else if (gameMode == 'M' || gameMode == 'm'){
      Input gameChild(maxTurns, num_players, maxTiles, snakes, ladders, num_penalties, num_rewards);
      gameChild.start();
      break;
    }
    else{
      std::cout<<"Invalid option, please press A to play with the default settings or M to play with your own settings"<<endl;
      cin >> gameMode;
    }
  }
 

  return 0;
}