/*
#ifndef NOINPUT_H
#define NOINPUT_H
#include "myGame.h"

class NoInput: public Input{
  void executeTurn() override;
};
#endif
*/