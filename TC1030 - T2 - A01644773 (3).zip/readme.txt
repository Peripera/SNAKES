# How the Snakes and ladders code work´s?

- Let's start with the instructions to compile the code and make the game work properly.

First its important to keep the program paths in the same order as in the zip file. This is why it is recommended when decompressing the file to leave the folders with the respective names, "include" and "src" in the c++ directory where you will execute the code.

To compile the game we use the directory "snakes.cpp" which will load all the files, and run the game logic, we use the compiler command: 

g++ snakes.cpp src/*.cpp -o snakes.out

After that you can run the code with

./snakes.out



## Discussion of the POO concepts 

In this Project, we use the fundamental OOP concepts of abstraction, encapsulation, and composition. By employing these concepts the codebase is structured to ensure clarity.


> The project embraces abstraction by the creation of distinct classes such as MyGame, Board, and Dice, each representing essential components of the game. These classes abstract away the complexities of their functionalities, allowing for easier management and manipulation of game elements. 


We also use  the fundamental OOP concpet of polymorphism to enhance flexibility, maintainability, and scalability. By employing polymorphism, we ensure that the codebase can easily adapt to different scenarios and requirements. The project demonstrates polymorphism through the use of a base class and derived classes, each implementing specific behaviors. 

The base class in this project is ‘Mygame’, this class serves as the foundation for the game’s core functionality. It defines virtual methods ‘executeTurn’ and ‘start’, which are intended to be overridden by derived classes. This abstraction allows the base class to provide a common interface for all game-related operations, while the specific behaviors are handled by subclasses. 

The ‘Input’ class inherits from ‘Mygame’ and provides specific implementations for the ‘executeTurn’ and ‘start’ methods. It handles user inputs during the game, enabling players to interact with the game and perform actions. 

We use Compile-time Polymorphisme to determine which version of the start() method should be executed at compile-time, since it is invoked using an object of the MyGame class, but the version defined in the derived classes is executed according to the type of the object at run-time.



##Functionality of the code and justification

-To understand the structure of the code we have to keep in mind that snakes.pp is where the logic of the code is initialized, i.e. the main code, my game is the parent class, input is inherited from my game.h.

-My game then defines the behavior of the game, containing all the methods that make up the snakes and ladders, including the number of turns allowed, players, number of snakes, number of ladders, penalties, rewards, maximum turns, as well as the board construction initiator and the dice simulation.Depending on the selected mode, an instance of MyGame or Input is created and the corresponding start method is called.

-The game initializes by setting up parameters such as the number of players, the size of the board, the number of snakes, ladders penalties, and rewards. This setup ensures that the game can be configured for different play styles and difficulties. 

-The board is created with a specified number of tiles. Snakes and ladders are placed on the board, along with penalties and rewards. This creates the game’s environment, providing challenges and advantages to the players as they progress.

-The snakes.cpp contains the main function which facilitates the creation of the game board with a specified number of tiles. It allows the user to define the number of snakes, ladders, penalties, and rewards, which are then placed on the board. This setup creates the game environment, introducing both challenges (snakes and penalties) and advantages (ladders and rewards) that players will encounter as they progress through the game. 


Input adds the ability to manage additional commands and modify turn execution. This allows using inheritance and polymorphism to extend and customize the game behavior by choosing the type and creates an instance of either MyGame or Input depending on the selected game mode.

In the development of the project, we considered using inheritance to represent different types of tiles such as regular tiles, snake, tiles, ladder tiles, penalty, and reward. However, after careful evaluation we decided it was unnecessary due to the simplicity and efficiency.